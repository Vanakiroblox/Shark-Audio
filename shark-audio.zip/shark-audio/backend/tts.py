import os
import wave
from pathlib import Path

from dotenv import load_dotenv
from google import genai
from google.genai import types


load_dotenv()


AUDIO_DIRECTORY = (
    Path(__file__).parent.parent / "audio"
)

AUDIO_DIRECTORY.mkdir(
    exist_ok=True
)


API_KEY = os.getenv("GEMINI_API_KEY")

if not API_KEY:
    raise RuntimeError(
        "GEMINI_API_KEY is missing from .env"
    )


client = genai.Client(
    api_key=API_KEY
)


# Gemini TTS model
TTS_MODEL = "gemini-2.5-flash-preview-tts"


def generate_speech(
    text: str,
    voice: str = "default"
):

    voice_map = {
        "default": "Kore",
        "narrator": "Charon",
        "energetic": "Puck",
    }

    voice_name = voice_map.get(
        voice,
        voice_map["default"]
    )


    response = client.models.generate_content(
        model=TTS_MODEL,

        contents=text,

        config=types.GenerateContentConfig(
            response_modalities=["AUDIO"],

            speech_config=types.SpeechConfig(
                voice_config=types.VoiceConfig(
                    prebuilt_voice_config=
                    types.PrebuiltVoiceConfig(
                        voice_name=voice_name
                    )
                )
            )
        )
    )


    audio_data = (
        response
        .candidates[0]
        .content
        .parts[0]
        .inline_data
        .data
    )


    filename = (
        f"shark_{os.urandom(8).hex()}.wav"
    )

    output_path = (
        AUDIO_DIRECTORY / filename
    )


    # Gemini returns raw PCM audio.
    # Convert it into a playable WAV file.
    with wave.open(
        str(output_path),
        "wb"
    ) as wav:

        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(24000)

        wav.writeframes(audio_data)


    return output_path