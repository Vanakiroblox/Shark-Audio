import os
import uuid
from pathlib import Path
from datetime import datetime

from fastapi import (
    APIRouter,
    HTTPException,
    UploadFile,
    File,
)

from database import (
    get_creator,
    create_verification,
    get_verification,
)


# ============================================================
# 🦈 SHARK AUDIO
# Voice Verification
# ============================================================

router = APIRouter(
    prefix="/api/verification",
    tags=["Verification"],
)


# ============================================================
# Paths
# ============================================================

BASE_DIR = Path(__file__).resolve().parent

VERIFICATION_DIR = (
    BASE_DIR.parent / "verification_uploads"
)

VERIFICATION_DIR.mkdir(
    exist_ok=True
)


# ============================================================
# Allowed verification methods
# ============================================================

ALLOWED_METHODS = {
    "voice_recording",
    "identity_document",
}


# ============================================================
# Allowed file types
# ============================================================

ALLOWED_AUDIO_TYPES = {
    "audio/wav",
    "audio/mpeg",
    "audio/mp3",
}

ALLOWED_DOCUMENT_TYPES = {
    "image/jpeg",
    "image/png",
    "application/pdf",
}


# ============================================================
# Status
# ============================================================

@router.get("/status")
def verification_status():

    creator = get_creator()

    if creator is None:

        raise HTTPException(
            status_code=403,
            detail=(
                "You need a Creator ID before "
                "starting verification."
            ),
        )


    verification = get_verification(
        creator["creator_id"]
    )


    return {

        "success": True,

        "creator_id": (
            creator["creator_id"]
        ),

        "verified": (
            creator["verified"]
        ),

        "verification": verification,

    }


# ============================================================
# Submit verification
# ============================================================

@router.post("/submit")
async def submit_verification(
    method: str,
    file: UploadFile = File(...),
):

    # --------------------------------------------------------
    # Creator ID
    # --------------------------------------------------------

    creator = get_creator()

    if creator is None:

        raise HTTPException(
            status_code=403,
            detail=(
                "Create a Creator ID before "
                "verifying your voice."
            ),
        )


    # --------------------------------------------------------
    # Already verified
    # --------------------------------------------------------

    if creator["verified"]:

        raise HTTPException(
            status_code=400,
            detail=(
                "This Creator ID is already verified."
            ),
        )


    # --------------------------------------------------------
    # Validate method
    # --------------------------------------------------------

    if method not in ALLOWED_METHODS:

        raise HTTPException(
            status_code=400,
            detail=(
                "Invalid verification method. "
                "Use voice_recording or "
                "identity_document."
            ),
        )


    # --------------------------------------------------------
    # Check existing verification
    # --------------------------------------------------------

    existing = get_verification(
        creator["creator_id"]
    )

    if existing:

        if existing["status"] == "pending":

            raise HTTPException(
                status_code=409,
                detail=(
                    "A verification request is "
                    "already pending."
                ),
            )


    # --------------------------------------------------------
    # File
    # --------------------------------------------------------

    if not file:

        raise HTTPException(
            status_code=400,
            detail="No verification file provided.",
        )


    # --------------------------------------------------------
    # MIME validation
    # --------------------------------------------------------

    content_type = (
        file.content_type
        or ""
    )


    if method == "voice_recording":

        if content_type not in ALLOWED_AUDIO_TYPES:

            raise HTTPException(
                status_code=400,
                detail=(
                    "Voice verification requires "
                    "an MP3 or WAV recording."
                ),
            )


    elif method == "identity_document":

        if content_type not in ALLOWED_DOCUMENT_TYPES:

            raise HTTPException(
                status_code=400,
                detail=(
                    "Identity verification requires "
                    "a JPG, PNG, or PDF."
                ),
            )


    # --------------------------------------------------------
    # Read file
    # --------------------------------------------------------

    file_bytes = await file.read()

    if not file_bytes:

        raise HTTPException(
            status_code=400,
            detail="Uploaded file is empty.",
        )


    # --------------------------------------------------------
    # Size limit
    # --------------------------------------------------------

    max_size = 15 * 1024 * 1024

    if len(file_bytes) > max_size:

        raise HTTPException(
            status_code=413,
            detail=(
                "Verification file is too large. "
                "Maximum size is 15 MB."
            ),
        )


    # --------------------------------------------------------
    # Generate private filename
    # --------------------------------------------------------

    extension = (
        Path(file.filename or "")
        .suffix
        .lower()
    )


    filename = (
        f"{uuid.uuid4().hex}"
        f"{extension}"
    )


    output_path = (
        VERIFICATION_DIR / filename
    )


    # --------------------------------------------------------
    # Save privately
    # --------------------------------------------------------

    output_path.write_bytes(
        file_bytes
    )


    # --------------------------------------------------------
    # Create verification record
    # --------------------------------------------------------

    verification_id = create_verification(
        creator["creator_id"],
        method,
    )


    # --------------------------------------------------------
    # IMPORTANT
    # --------------------------------------------------------
    # This does NOT automatically verify the creator.
    #
    # It creates a pending verification request.
    # --------------------------------------------------------

    print()
    print("🔐 VERIFICATION SUBMITTED")
    print(
        "Creator:",
        creator["creator_id"]
    )
    print(
        "Method:",
        method
    )
    print(
        "Verification ID:",
        verification_id
    )
    print()


    return {

        "success": True,

        "verification_id": (
            verification_id
        ),

        "status": "pending",

        "message": (
            "Verification submitted. "
            "Your verification must be reviewed "
            "before the Creator ID becomes verified."
        ),

    }