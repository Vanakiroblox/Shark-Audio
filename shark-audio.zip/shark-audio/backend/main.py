import os
from pathlib import Path

from dotenv import load_dotenv

from fastapi import (
    FastAPI,
    HTTPException,
    UploadFile,
    File,
)

from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from verification import router as verification_router
from voices import router as voices_router

from pydantic import BaseModel

from google import genai

from database import (
    init_database,
    add_activity,
    get_recent_activity,
    get_creator,
    create_creator,
)

from creator import (
    generate_creator_id,
    creator_created_at,
)

from tts import generate_speech
from stt import transcribe_audio
from story import generate_story


# ============================================================
# 🦈 SHARK AUDIO
# Main backend
# ============================================================

load_dotenv()


# ============================================================
# Paths
# ============================================================

BASE_DIR = Path(__file__).resolve().parent

AUDIO_DIR = BASE_DIR.parent / "audio"

AUDIO_DIR.mkdir(
    exist_ok=True
)


# ============================================================
# Gemini
# ============================================================

GEMINI_API_KEY = os.getenv(
    "GEMINI_API_KEY"
)

if not GEMINI_API_KEY:

    print(
        "⚠️ GEMINI_API_KEY is missing!"
    )

    gemini_client = None

else:

    gemini_client = genai.Client(
        api_key=GEMINI_API_KEY
    )


# ============================================================
# FastAPI
# ============================================================

app = FastAPI(
    title="Shark Audio API",
    description="The backend for Shark Audio 🦈",
    version="0.1.0",
)


# ============================================================
# CORS
# ============================================================

app.add_middleware(
    CORSMiddleware,

    allow_origins=["*"],

    allow_credentials=False,

    allow_methods=["*"],

    allow_headers=["*"],
)

app.include_router(
    verification_router
)

app.include_router(
    voices_router
)

# ============================================================
# Audio files
# ============================================================

app.mount(
    "/audio",
    StaticFiles(
        directory=str(AUDIO_DIR)
    ),
    name="audio",
)


# ============================================================
# Request models
# ============================================================

class GeminiRequest(BaseModel):

    prompt: str


class TTSRequest(BaseModel):

    text: str

    voice: str = "default"


class StoryRequest(BaseModel):

    title: str = "Untitled Story"

    text: str

    voice: str = "default"


# ============================================================
# Startup
# ============================================================

@app.on_event("startup")
def startup():

    init_database()

    print()

    print("========================================")
    print("       🦈 SHARK AUDIO ONLINE")
    print("========================================")

    if gemini_client:

        print("🧠 Gemini: CONNECTED")

    else:

        print("🧠 Gemini: NOT CONFIGURED")

    print("🔊 TTS: READY")
    print("🎙️ STT: READY")
    print("📖 Story Studio: READY")
    print("🆔 Creator ID: READY")

    print("========================================")
    print()


# ============================================================
# Root
# ============================================================

@app.get("/")
def root():

    return {

        "name": "Shark Audio",

        "version": "0.1.0",

        "status": "online",

        "gemini": (
            "connected"
            if gemini_client
            else "not_configured"
        ),

    }


# ============================================================
# Health
# ============================================================

@app.get("/api/health")
def health():

    return {

        "status": "healthy",

        "gemini": (
            gemini_client is not None
        ),

    }


# ============================================================
# Recent activity
# ============================================================

@app.get("/api/activity")
def activity():

    return {

        "activity": get_recent_activity()

    }


# ============================================================
# 🧠 GEMINI
# ============================================================

@app.post("/api/gemini")
def ask_gemini(
    request: GeminiRequest
):

    prompt = request.prompt.strip()

    if not prompt:

        raise HTTPException(
            status_code=400,
            detail="Prompt cannot be empty.",
        )

    if gemini_client is None:

        raise HTTPException(
            status_code=503,
            detail=(
                "Gemini API key is not configured."
            ),
        )

    try:

        response = (
            gemini_client.models.generate_content(

                model="gemini-3.6-flash",

                contents=prompt,

            )
        )

        return {

            "success": True,

            "response": response.text,

        }

    except Exception as error:

        print()
        print("❌ Gemini ERROR")
        print(error)
        print()

        raise HTTPException(
            status_code=500,
            detail="Gemini request failed.",
        )


# ============================================================
# 🔊 TEXT TO SPEECH
# ============================================================

@app.post("/api/tts")
def text_to_speech(
    request: TTSRequest
):

    text = request.text.strip()

    if not text:

        raise HTTPException(
            status_code=400,
            detail="Text cannot be empty.",
        )

    if len(text) > 1000:

        raise HTTPException(
            status_code=400,
            detail=(
                "TTS is limited to 1000 characters. "
                "Use Story Studio for long-form audio."
            ),
        )

    print()
    print("🦈 TTS request")
    print("Voice:", request.voice)
    print("Characters:", len(text))
    print()

    try:

        output_path = generate_speech(
            text=text,
            voice=request.voice,
        )

        add_activity(
            "tts",
            text[:100],
            "completed",
        )

        return {

            "success": True,

            "audio_url": (
                f"/audio/{output_path.name}"
            ),

            "voice": request.voice,

            "characters": len(text),

        }

    except Exception as error:

        print()
        print("❌ TTS ERROR")
        print(error)
        print()

        raise HTTPException(
            status_code=500,
            detail=f"TTS generation failed: {error}",
        )


# ============================================================
# 📖 STORY STUDIO
# ============================================================

@app.post("/api/story")
def create_story(
    request: StoryRequest
):

    title = request.title.strip()
    text = request.text.strip()

    if not text:

        raise HTTPException(
            status_code=400,
            detail="Story text cannot be empty.",
        )

    if len(text) > 50000:

        raise HTTPException(
            status_code=400,
            detail=(
                "Story Studio is limited to "
                "50,000 characters."
            ),
        )

    print()
    print("📖 STORY REQUEST")
    print("Title:", title)
    print("Voice:", request.voice)
    print("Characters:", len(text))
    print()

    try:

        output_path = generate_story(
            text=text,
            voice=request.voice,
        )

        add_activity(
            "story",
            title[:100],
            "completed",
        )

        return {

            "success": True,

            "title": title,

            "audio_url": (
                f"/audio/{output_path.name}"
            ),

            "voice": request.voice,

            "characters": len(text),

        }

    except Exception as error:

        print()
        print("❌ STORY ERROR")
        print(error)
        print()

        raise HTTPException(
            status_code=500,
            detail=f"Story generation failed: {error}",
        )


# ============================================================
# 🆔 CREATOR ID
# ============================================================

@app.get("/api/creator")
def creator_status():

    creator = get_creator()

    if creator is None:

        return {

            "success": True,

            "has_creator_id": False,

            "creator": None,

        }

    return {

        "success": True,

        "has_creator_id": True,

        "creator": creator,

    }


@app.post("/api/creator")
def create_creator_id():

    existing = get_creator()

    if existing:

        return {

            "success": True,

            "created": False,

            "creator": existing,

            "message": (
                "This account already has a "
                "permanent Creator ID."
            ),

        }

    creator_id = generate_creator_id()

    created_at = creator_created_at()

    try:

        create_creator(
            creator_id,
            created_at,
        )

    except Exception as error:

        print()
        print("❌ Creator ID ERROR")
        print(error)
        print()

        raise HTTPException(
            status_code=500,
            detail="Could not create Creator ID.",
        )

    add_activity(
        "creator",
        "Creator ID created",
        "completed",
    )

    return {

        "success": True,

        "created": True,

        "creator": {

            "creator_id": creator_id,

            "verified": False,

            "verification_method": None,

            "created_at": created_at,

        },

        "message": (
            "Your permanent Creator ID has "
            "been created."
        ),

    }


# ============================================================
# 🎙️ SPEECH TO TEXT
# ============================================================

@app.post("/api/stt")
async def speech_to_text(
    file: UploadFile = File(...)
):

    if not file:

        raise HTTPException(
            status_code=400,
            detail="No audio file provided.",
        )

    try:

        audio_bytes = await file.read()

    except Exception as error:

        raise HTTPException(
            status_code=400,
            detail=(
                f"Could not read audio file: {error}"
            ),
        )

    if not audio_bytes:

        raise HTTPException(
            status_code=400,
            detail="Audio file is empty.",
        )

    mime_type = (
        file.content_type
        or "audio/wav"
    )

    print()
    print("🎙️ STT request")
    print("File:", file.filename)
    print("Type:", mime_type)
    print("Size:", len(audio_bytes), "bytes")
    print()

    try:

        transcript = transcribe_audio(
            audio_bytes,
            mime_type,
        )

        add_activity(
            "stt",
            transcript[:100],
            "completed",
        )

        return {

            "success": True,

            "transcript": transcript,

            "filename": file.filename,

        }

    except Exception as error:

        print()
        print("❌ STT ERROR")
        print(error)
        print()

        raise HTTPException(
            status_code=500,
            detail=f"STT failed: {error}",
        )