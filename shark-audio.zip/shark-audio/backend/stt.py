import os

from dotenv import load_dotenv
from google import genai
from google.genai import types


# ============================================================
# 🎙️ SHARK AUDIO
# Speech-to-Text service
# ============================================================

load_dotenv()


# ============================================================
# Gemini
# ============================================================

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")


if not GEMINI_API_KEY:

    print("⚠️ GEMINI_API_KEY is missing!")

    client = None

else:

    client = genai.Client(
        api_key=GEMINI_API_KEY
    )


# ============================================================
# 🎙️ TRANSCRIBE AUDIO
# ============================================================

def transcribe_audio(
    audio_bytes: bytes,
    mime_type: str = "audio/wav",
) -> str:

    # --------------------------------------------------------
    # Check Gemini
    # --------------------------------------------------------

    if client is None:

        raise RuntimeError(
            "Gemini API key is not configured."
        )


    # --------------------------------------------------------
    # Check audio
    # --------------------------------------------------------

    if not audio_bytes:

        raise ValueError(
            "Audio file is empty."
        )


    # --------------------------------------------------------
    # Normalize MIME type
    # --------------------------------------------------------

    if not mime_type:

        mime_type = "audio/wav"


    # --------------------------------------------------------
    # Send audio to Gemini
    # --------------------------------------------------------

    response = client.models.generate_content(

        model="gemini-3.6-flash",

        contents=[
            types.Part.from_bytes(
                data=audio_bytes,
                mime_type=mime_type,
            ),

            (
                "Transcribe this audio exactly. "
                "Return only the spoken transcript. "
                "Do not add commentary, explanations, "
                "or formatting."
            ),
        ],
    )


    # --------------------------------------------------------
    # Get transcript
    # --------------------------------------------------------

    if not response.text:

        raise RuntimeError(
            "Gemini returned an empty transcript."
        )


    transcript = response.text.strip()


    # --------------------------------------------------------
    # Final validation
    # --------------------------------------------------------

    if not transcript:

        raise RuntimeError(
            "Transcript is empty."
        )


    return transcript