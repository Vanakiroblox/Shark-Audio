import secrets
import string
from datetime import datetime, timezone


# ============================================================
# 🆔 SHARK AUDIO CREATOR ID
# ============================================================

CREATOR_PREFIX = "SA"


def generate_creator_id():
    """
    Generate a permanent Shark Audio Creator ID.

    Example:

        SA-7K4M-X92Q-PL8D
    """

    alphabet = (
        string.ascii_uppercase
        + string.digits
    )

    # Remove characters that can easily be confused.
    alphabet = alphabet.replace("O", "")
    alphabet = alphabet.replace("0", "")
    alphabet = alphabet.replace("I", "")
    alphabet = alphabet.replace("1", "")

    part1 = "".join(
        secrets.choice(alphabet)
        for _ in range(4)
    )

    part2 = "".join(
        secrets.choice(alphabet)
        for _ in range(4)
    )

    part3 = "".join(
        secrets.choice(alphabet)
        for _ in range(4)
    )

    return (
        f"{CREATOR_PREFIX}-"
        f"{part1}-"
        f"{part2}-"
        f"{part3}"
    )


def creator_created_at():
    """
    Return a UTC timestamp for Creator ID creation.
    """

    return datetime.now(
        timezone.utc
    ).isoformat()