import uuid
from pathlib import Path

from fastapi import (
    APIRouter,
    HTTPException,
    UploadFile,
    File,
    Form,
)

from database import (
    get_creator,
    create_voice,
    get_creator_voices,
)


# ============================================================
# 🧬 SHARK AUDIO
# Voice Lab
# ============================================================

router = APIRouter(
    prefix="/api/voices",
    tags=["Voice Lab"],
)


# ============================================================
# Paths
# ============================================================

BASE_DIR = Path(__file__).resolve().parent

VOICE_DIR = (
    BASE_DIR.parent / "voices"
)

VOICE_DIR.mkdir(
    exist_ok=True
)


# ============================================================
# Allowed audio
# ============================================================

ALLOWED_AUDIO_TYPES = {
    "audio/wav",
    "audio/mpeg",
    "audio/mp3",
}


# ============================================================
# Voice Lab status
# ============================================================

@router.get("/status")
def voice_lab_status():

    creator = get_creator()

    if creator is None:

        return {

            "success": True,

            "can_create_voice": False,

            "reason": "creator_id_required",

        }


    if not creator["verified"]:

        return {

            "success": True,

            "can_create_voice": False,

            "reason": "creator_verification_required",

            "creator_id": (
                creator["creator_id"]
            ),

        }


    return {

        "success": True,

        "can_create_voice": True,

        "creator_id": (
            creator["creator_id"]
        ),

    }


# ============================================================
# Get my voices
# ============================================================

@router.get("/")
def my_voices():

    creator = get_creator()

    if creator is None:

        raise HTTPException(
            status_code=403,
            detail="Creator ID required.",
        )


    voices = get_creator_voices(
        creator["creator_id"]
    )


    return {

        "success": True,

        "voices": voices,

    }


# ============================================================
# Create voice
# ============================================================

@router.post("/create")
async def create_voice_endpoint(

    name: str = Form(...),

    description: str = Form(""),

    file: UploadFile = File(...),

):

    # --------------------------------------------------------
    # Creator
    # --------------------------------------------------------

    creator = get_creator()

    if creator is None:

        raise HTTPException(
            status_code=403,
            detail=(
                "You must create a Creator ID "
                "before creating a voice."
            ),
        )


    # --------------------------------------------------------
    # Verification
    # --------------------------------------------------------

    if not creator["verified"]:

        raise HTTPException(
            status_code=403,
            detail=(
                "Your Creator ID must be verified "
                "before creating voices."
            ),
        )


    # --------------------------------------------------------
    # Name
    # --------------------------------------------------------

    name = name.strip()

    if not name:

        raise HTTPException(
            status_code=400,
            detail="Voice name cannot be empty.",
        )


    if len(name) > 100:

        raise HTTPException(
            status_code=400,
            detail=(
                "Voice name is limited "
                "to 100 characters."
            ),
        )


    # --------------------------------------------------------
    # File
    # --------------------------------------------------------

    if not file:

        raise HTTPException(
            status_code=400,
            detail="No voice recording provided.",
        )


    content_type = (
        file.content_type
        or ""
    )


    if content_type not in ALLOWED_AUDIO_TYPES:

        raise HTTPException(
            status_code=400,
            detail=(
                "Voice samples must be "
                "MP3 or WAV files."
            ),
        )


    # --------------------------------------------------------
    # Read audio
    # --------------------------------------------------------

    audio_bytes = await file.read()

    if not audio_bytes:

        raise HTTPException(
            status_code=400,
            detail="Voice recording is empty.",
        )


    # --------------------------------------------------------
    # Size limit
    # --------------------------------------------------------

    max_size = 25 * 1024 * 1024

    if len(audio_bytes) > max_size:

        raise HTTPException(
            status_code=413,
            detail=(
                "Voice recording is too large. "
                "Maximum size is 25 MB."
            ),
        )


    # --------------------------------------------------------
    # Private filename
    # --------------------------------------------------------

    extension = (
        Path(file.filename or "")
        .suffix
        .lower()
    )


    filename = (
        f"voice_{uuid.uuid4().hex}"
        f"{extension}"
    )


    output_path = (
        VOICE_DIR / filename
    )


    output_path.write_bytes(
        audio_bytes
    )


    # --------------------------------------------------------
    # Database
    # --------------------------------------------------------

    voice_id = create_voice(

        creator_id=(
            creator["creator_id"]
        ),

        name=name,

        description=description.strip(),

        audio_path=str(
            output_path
        ),

    )


    # --------------------------------------------------------
    # IMPORTANT
    # --------------------------------------------------------
    # New voices start as "pending".
    # They are NOT automatically public.
    # --------------------------------------------------------

    return {

        "success": True,

        "voice_id": voice_id,

        "name": name,

        "status": "pending",

        "public": False,

        "message": (
            "Voice submitted successfully. "
            "It is currently private and pending review."
        ),

    }