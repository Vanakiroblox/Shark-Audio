import sqlite3
from pathlib import Path
from datetime import datetime, timezone


# ============================================================
# 🦈 SHARK AUDIO DATABASE
# ============================================================

BASE_DIR = Path(__file__).resolve().parent

DATABASE_PATH = BASE_DIR / "shark_audio.db"


# ============================================================
# CONNECTION
# ============================================================

def get_connection():

    connection = sqlite3.connect(
        DATABASE_PATH
    )

    connection.row_factory = sqlite3.Row

    return connection


# ============================================================
# DATABASE INITIALIZATION
# ============================================================

def init_database():

    connection = get_connection()

    cursor = connection.cursor()


    # --------------------------------------------------------
    # Activity
    # --------------------------------------------------------

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS activity (

            id INTEGER PRIMARY KEY AUTOINCREMENT,

            type TEXT NOT NULL,

            title TEXT NOT NULL,

            status TEXT NOT NULL,

            created_at TEXT NOT NULL

        )
    """)


    # --------------------------------------------------------
    # Creator
    # --------------------------------------------------------

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS creator (

            id INTEGER PRIMARY KEY CHECK (id = 1),

            creator_id TEXT UNIQUE NOT NULL,

            verified INTEGER NOT NULL DEFAULT 0,

            verification_method TEXT,

            created_at TEXT NOT NULL

        )
    """)


    # --------------------------------------------------------
    # Voices
    # --------------------------------------------------------

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS voices (

            id INTEGER PRIMARY KEY AUTOINCREMENT,

            creator_id TEXT NOT NULL,

            name TEXT NOT NULL,

            description TEXT,

            audio_filename TEXT NOT NULL,

            public INTEGER NOT NULL DEFAULT 0,

            verified INTEGER NOT NULL DEFAULT 0,

            created_at TEXT NOT NULL

        )
    """)


    connection.commit()

    connection.close()


# ============================================================
# ACTIVITY
# ============================================================

def add_activity(
    activity_type,
    title,
    status
):

    connection = get_connection()

    cursor = connection.cursor()


    created_at = datetime.now(
        timezone.utc
    ).isoformat()


    cursor.execute(
        """
        INSERT INTO activity
        (
            type,
            title,
            status,
            created_at
        )

        VALUES (?, ?, ?, ?)
        """,
        (
            activity_type,
            title,
            status,
            created_at,
        )
    )


    connection.commit()

    connection.close()


def get_recent_activity(
    limit=20
):

    connection = get_connection()

    cursor = connection.cursor()


    cursor.execute(
        """
        SELECT
            id,
            type,
            title,
            status,
            created_at

        FROM activity

        ORDER BY id DESC

        LIMIT ?
        """,
        (limit,)
    )


    rows = cursor.fetchall()

    connection.close()


    return [
        dict(row)
        for row in rows
    ]


# ============================================================
# 🆔 CREATOR ID
# ============================================================

def get_creator():

    connection = get_connection()

    cursor = connection.cursor()


    cursor.execute(
        """
        SELECT
            creator_id,
            verified,
            verification_method,
            created_at

        FROM creator

        WHERE id = 1
        """
    )


    row = cursor.fetchone()

    connection.close()


    if row is None:
        return None


    return {
        "creator_id": row["creator_id"],
        "verified": bool(row["verified"]),
        "verification_method": row[
            "verification_method"
        ],
        "created_at": row["created_at"],
    }


def create_creator(
    creator_id,
    created_at
):

    connection = get_connection()

    cursor = connection.cursor()


    cursor.execute(
        """
        INSERT INTO creator
        (
            id,
            creator_id,
            verified,
            verification_method,
            created_at
        )

        VALUES
        (
            1,
            ?,
            0,
            NULL,
            ?
        )
        """,
        (
            creator_id,
            created_at,
        )
    )


    connection.commit()

    connection.close()


# ============================================================
# CREATOR VERIFICATION
# ============================================================

def verify_creator(
    verification_method
):

    connection = get_connection()

    cursor = connection.cursor()


    cursor.execute(
        """
        UPDATE creator

        SET
            verified = 1,
            verification_method = ?

        WHERE id = 1
        """,
        (
            verification_method,
        )
    )


    connection.commit()

    connection.close()


# ============================================================
# VOICES
# ============================================================

def create_voice(
    creator_id,
    name,
    description,
    audio_filename,
    public=False
):

    connection = get_connection()

    cursor = connection.cursor()


    created_at = datetime.now(
        timezone.utc
    ).isoformat()


    cursor.execute(
        """
        INSERT INTO voices
        (
            creator_id,
            name,
            description,
            audio_filename,
            public,
            verified,
            created_at
        )

        VALUES (?, ?, ?, ?, ?, 0, ?)
        """,
        (
            creator_id,
            name,
            description,
            audio_filename,
            int(public),
            created_at,
        )
    )


    voice_id = cursor.lastrowid


    connection.commit()

    connection.close()


    return voice_id


def get_creator_voices(
    creator_id
):

    connection = get_connection()

    cursor = connection.cursor()


    cursor.execute(
        """
        SELECT
            id,
            creator_id,
            name,
            description,
            audio_filename,
            public,
            verified,
            created_at

        FROM voices

        WHERE creator_id = ?

        ORDER BY id DESC
        """,
        (
            creator_id,
        )
    )


    rows = cursor.fetchall()

    connection.close()


    return [
        {
            "id": row["id"],
            "creator_id": row["creator_id"],
            "name": row["name"],
            "description": row["description"],
            "audio_filename": row[
                "audio_filename"
            ],
            "public": bool(row["public"]),
            "verified": bool(row["verified"]),
            "created_at": row["created_at"],
        }

        for row in rows
    ]


def get_public_voices():

    connection = get_connection()

    cursor = connection.cursor()


    cursor.execute(
        """
        SELECT
            id,
            creator_id,
            name,
            description,
            audio_filename,
            verified,
            created_at

        FROM voices

        WHERE public = 1
        AND verified = 1

        ORDER BY id DESC
        """
    )


    rows = cursor.fetchall()

    connection.close()


    return [
        {
            "id": row["id"],
            "creator_id": row["creator_id"],
            "name": row["name"],
            "description": row["description"],
            "audio_filename": row[
                "audio_filename"
            ],
            "verified": bool(row["verified"]),
            "created_at": row["created_at"],
        }

        for row in rows
    ]