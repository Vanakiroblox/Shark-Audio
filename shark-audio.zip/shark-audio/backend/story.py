import os
import re
import uuid
import wave
from pathlib import Path

from dotenv import load_dotenv
from google import genai
from google.genai import types


# ============================================================
# 📖 SHARK AUDIO
# Story Studio
# ============================================================

load_dotenv()


# ============================================================
# Configuration
# ============================================================

API_KEY = os.getenv("GEMINI_API_KEY")

if not API_KEY:
    raise RuntimeError(
        "GEMINI_API_KEY is missing from .env"
    )


client = genai.Client(
    api_key=API_KEY
)


TTS_MODEL = "gemini-2.5-flash-preview-tts"


VOICE_MAP = {
    "default": "Kore",
    "narrator": "Charon",
    "energetic": "Puck",
}


# Gemini TTS returns 24 kHz, 16-bit mono PCM.
SAMPLE_RATE = 24000
CHANNELS = 1
SAMPLE_WIDTH = 2


# ============================================================
# Voice
# ============================================================

def get_voice_name(voice: str) -> str:

    return VOICE_MAP.get(
        voice,
        VOICE_MAP["default"]
    )


# ============================================================
# WAV helpers
# ============================================================

def write_wav(
    path: Path,
    pcm_data: bytes,
):
    """
    Convert Gemini's raw PCM data into a WAV file.
    """

    with wave.open(
        str(path),
        "wb"
    ) as wav:

        wav.setnchannels(
            CHANNELS
        )

        wav.setsampwidth(
            SAMPLE_WIDTH
        )

        wav.setframerate(
            SAMPLE_RATE
        )

        wav.writeframes(
            pcm_data
        )


def read_wav_pcm(
    path: Path,
) -> bytes:

    with wave.open(
        str(path),
        "rb"
    ) as wav:

        return wav.readframes(
            wav.getnframes()
        )


# ============================================================
# Story chunking
# ============================================================

def split_story(
    text: str,
    max_chars: int = 900,
):
    """
    Split a long story into manageable pieces.

    We try to split on paragraphs first,
    then sentences, then hard character limits.
    """

    text = text.strip()

    if not text:
        return []


    paragraphs = re.split(
        r"\n\s*\n",
        text,
    )


    chunks = []

    current = ""


    for paragraph in paragraphs:

        paragraph = paragraph.strip()

        if not paragraph:
            continue


        # ----------------------------------------------------
        # Paragraph fits
        # ----------------------------------------------------

        if len(current) + len(paragraph) + 2 <= max_chars:

            if current:

                current += "\n\n"

            current += paragraph

            continue


        # ----------------------------------------------------
        # Save current chunk
        # ----------------------------------------------------

        if current:

            chunks.append(
                current.strip()
            )

            current = ""


        # ----------------------------------------------------
        # Paragraph itself is too large
        # ----------------------------------------------------

        if len(paragraph) <= max_chars:

            current = paragraph

            continue


        # ----------------------------------------------------
        # Sentence splitting
        # ----------------------------------------------------

        sentences = re.split(
            r"(?<=[.!?])\s+",
            paragraph,
        )


        for sentence in sentences:

            sentence = sentence.strip()

            if not sentence:
                continue


            if (
                len(current)
                + len(sentence)
                + 1
                <= max_chars
            ):

                if current:
                    current += " "

                current += sentence

            else:

                if current:

                    chunks.append(
                        current.strip()
                    )

                current = sentence


                # ------------------------------------------------
                # Extremely long sentence
                # ------------------------------------------------

                while len(current) > max_chars:

                    chunks.append(
                        current[:max_chars]
                    )

                    current = (
                        current[max_chars:]
                    )


    if current:

        chunks.append(
            current.strip()
        )


    return chunks


# ============================================================
# Generate one chunk
# ============================================================

def generate_chunk(
    text: str,
    voice: str,
):
    """
    Generate raw PCM audio for one story chunk.
    """

    voice_name = get_voice_name(
        voice
    )


    response = client.models.generate_content(

        model=TTS_MODEL,

        contents=text,

        config=types.GenerateContentConfig(

            response_modalities=[
                "AUDIO"
            ],

            speech_config=types.SpeechConfig(

                voice_config=types.VoiceConfig(

                    prebuilt_voice_config=
                    types.PrebuiltVoiceConfig(

                        voice_name=voice_name

                    )

                )

            )

        )

    )


    if not response.candidates:

        raise RuntimeError(
            "Gemini returned no candidates."
        )


    for candidate in response.candidates:

        if not candidate.content:
            continue


        for part in candidate.content.parts:

            if (
                part.inline_data
                and part.inline_data.data
            ):

                return part.inline_data.data


    raise RuntimeError(
        "Gemini returned no audio data."
    )


# ============================================================
# Combine PCM
# ============================================================

def combine_pcm(
    chunks,
):
    """
    Combine PCM chunks into one byte stream.
    """

    return b"".join(
        chunks
    )


# ============================================================
# Generate Story
# ============================================================

def generate_story(
    text: str,
    voice: str,
    audio_directory: Path,
):
    """
    Generate a complete long-form story.

    Returns information about the generated WAV.
    """

    text = text.strip()


    if not text:

        raise ValueError(
            "Story text cannot be empty."
        )


    # --------------------------------------------------------
    # Split story
    # --------------------------------------------------------

    chunks = split_story(
        text
    )


    if not chunks:

        raise ValueError(
            "Could not create story chunks."
        )


    print()
    print(
        "📖 STORY GENERATION"
    )
    print(
        "Chunks:",
        len(chunks)
    )
    print(
        "Voice:",
        voice
    )
    print()


    pcm_chunks = []


    # --------------------------------------------------------
    # Generate each chunk
    # --------------------------------------------------------

    for index, chunk in enumerate(
        chunks,
        start=1,
    ):

        print(
            f"📖 Generating chunk "
            f"{index}/{len(chunks)}..."
        )


        pcm = generate_chunk(
            chunk,
            voice,
        )


        pcm_chunks.append(
            pcm
        )


    # --------------------------------------------------------
    # Combine
    # --------------------------------------------------------

    combined_pcm = combine_pcm(
        pcm_chunks
    )


    # --------------------------------------------------------
    # Save final story
    # --------------------------------------------------------

    filename = (
        f"story_{uuid.uuid4().hex}.wav"
    )


    output_path = (
        audio_directory / filename
    )


    write_wav(
        output_path,
        combined_pcm,
    )


    print()
    print(
        "✅ Story generated!"
    )

    print(
        "File:",
        output_path
    )

    print()


    return {

        "filename": filename,

        "path": output_path,

        "chunks": len(chunks),

        "characters": len(text),

        "voice": voice,

    }