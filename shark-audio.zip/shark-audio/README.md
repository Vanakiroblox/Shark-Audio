## Shark Audio - v.1.01

## 1. Introduction

Shark Audio is a platform where you can use our rich TTS service powered by Google Gemini. We also have STT and Story Studio services. No paid plans here.

## 2. Text-To-Speech

Our rich TTS service offers voices in the highest quality possible. Made by other creators like you, many voices are tag-compatible, meaning they are expressive. Use [laugh] to make your voice laugh before or after a sentence. There are more tags like this!

## 3. Speech-To-Text

Our high-quality STT service offers text with fonts, styles, colors and more. Creators like you can make their own Text, packed with fonts and more.

## 4. Story Studio

Here, you can make long-form story voices with TTS. The only difference from the TTS model is that it's more simple-friendly, compact and no chracter caps.

Thanks for reading this! Open "backend" -> "index.html" and enjoy Shark Audio!