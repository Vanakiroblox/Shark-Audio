// ============================================================
// 🦈 SHARK AUDIO
// Frontend
// ============================================================

const API_BASE = "http://127.0.0.1:8000";


// ============================================================
// NAVIGATION
// ============================================================

const pages = document.querySelectorAll(".page");
const navItems = document.querySelectorAll("[data-page]");

const pageTitle =
    document.getElementById("page-title");

const titles = {

    home: "Welcome back 👋",

    tts: "Text to Speech 🔊",

    stt: "Speech to Text 🎙️",

    story: "Story Studio 📖",

    voices: "Voice Lab 🧬",

    library: "Voice Library 🌎"

};


function showPage(pageName) {

    pages.forEach(page => {

        page.classList.remove(
            "active-page"
        );

    });


    navItems.forEach(item => {

        item.classList.remove(
            "active"
        );

    });


    const page =
        document.getElementById(
            `${pageName}-page`
        );


    if (page) {

        page.classList.add(
            "active-page"
        );

    }


    document
        .querySelectorAll(
            `[data-page="${pageName}"]`
        )
        .forEach(item => {

            item.classList.add(
                "active"
            );

        });


    if (pageTitle) {

        pageTitle.textContent =
            titles[pageName] ||
            "Shark Audio";

    }


    // Load Voice Lab when opened

    if (pageName === "voices") {

        loadCreator();

    }

}


navItems.forEach(item => {

    item.addEventListener(
        "click",
        () => {

            const pageName =
                item.dataset.page;

            showPage(pageName);

        }
    );

});


// ============================================================
// TTS CHARACTER COUNTER
// ============================================================

const ttsText =
    document.getElementById(
        "ttsText"
    );

const charCount =
    document.getElementById(
        "charCount"
    );


if (ttsText && charCount) {

    ttsText.addEventListener(
        "input",
        () => {

            charCount.textContent =
                `${ttsText.value.length} / 1000`;

        }
    );

}


// ============================================================
// NEW BUTTON
// ============================================================

const newButton =
    document.getElementById(
        "newButton"
    );


if (newButton) {

    newButton.addEventListener(
        "click",
        () => {

            showPage("tts");

            if (ttsText) {

                ttsText.focus();

            }

        }
    );

}


// ============================================================
// AUDIO FILE
// ============================================================

const chooseAudio =
    document.getElementById(
        "chooseAudio"
    );

const audioFile =
    document.getElementById(
        "audioFile"
    );

const selectedFile =
    document.getElementById(
        "selectedFile"
    );

const transcribeSTT =
    document.getElementById(
        "transcribeSTT"
    );


if (chooseAudio && audioFile) {

    chooseAudio.addEventListener(
        "click",
        () => {

            audioFile.click();

        }
    );

}


if (audioFile) {

    audioFile.addEventListener(
        "change",
        () => {

            const file =
                audioFile.files[0];


            if (!file) {

                if (selectedFile) {

                    selectedFile.textContent =
                        "";

                }

                if (transcribeSTT) {

                    transcribeSTT.disabled =
                        true;

                }

                return;

            }


            if (selectedFile) {

                selectedFile.textContent =
                    `Selected: ${file.name}`;

            }


            if (transcribeSTT) {

                transcribeSTT.disabled =
                    false;

            }

        }
    );

}


// ============================================================
// STT
// ============================================================

if (transcribeSTT) {

    transcribeSTT.addEventListener(
        "click",
        async () => {

            const file =
                audioFile.files[0];


            if (!file) {

                return;

            }


            const result =
                document.getElementById(
                    "sttResult"
                );


            transcribeSTT.disabled =
                true;

            transcribeSTT.textContent =
                "🦈 Transcribing...";


            const formData =
                new FormData();


            formData.append(
                "file",
                file
            );


            try {

                const response =
                    await fetch(
                        `${API_BASE}/api/stt`,
                        {
                            method: "POST",
                            body: formData
                        }
                    );


                const data =
                    await response.json();


                if (!response.ok) {

                    throw new Error(
                        data.detail ||
                        "STT failed."
                    );

                }


                if (result) {

                    result.textContent =
                        data.transcript;

                }


                await loadActivity();

            }
            catch (error) {

                console.error(
                    "STT error:",
                    error
                );


                if (result) {

                    result.textContent =
                        `❌ ${error.message}`;

                }

            }
            finally {

                transcribeSTT.disabled =
                    false;

                transcribeSTT.textContent =
                    "🎙️ Transcribe";

            }

        }
    );

}


// ============================================================
// ACTIVITY
// ============================================================

async function loadActivity() {

    const activity =
        document.getElementById(
            "activity"
        );


    if (!activity) {

        return;

    }


    try {

        const response =
            await fetch(
                `${API_BASE}/api/activity`
            );


        if (!response.ok) {

            throw new Error(
                "Failed to load activity"
            );

        }


        const data =
            await response.json();


        if (
            !data.activity ||
            !data.activity.length
        ) {

            return;

        }


        activity.innerHTML =
            "";


        data.activity.forEach(
            item => {

                const element =
                    document.createElement(
                        "div"
                    );


                element.className =
                    "activity-item";


                const icon =
                    item.type === "tts"
                        ? "🔊"
                        : item.type === "stt"
                        ? "🎙️"
                        : "🆔";


                element.innerHTML = `

                    <div class="activity-icon">
                        ${icon}
                    </div>

                    <div class="activity-info">

                        <div class="activity-title">
                            ${escapeHTML(
                                item.title
                            )}
                        </div>

                        <div class="activity-meta">

                            ${escapeHTML(
                                item.type
                            ).toUpperCase()}

                            •

                            ${escapeHTML(
                                item.status
                            )}

                            •

                            ${escapeHTML(
                                item.created_at
                            )}

                        </div>

                    </div>

                `;


                activity.appendChild(
                    element
                );

            }
        );

    }
    catch (error) {

        console.error(
            "Could not load activity:",
            error
        );

    }

}


const refreshActivity =
    document.getElementById(
        "refreshActivity"
    );


if (refreshActivity) {

    refreshActivity.addEventListener(
        "click",
        loadActivity
    );

}


// ============================================================
// TTS
// ============================================================

const generateTTS =
    document.getElementById(
        "generateTTS"
    );

const ttsResult =
    document.getElementById(
        "ttsResult"
    );


if (generateTTS) {

    generateTTS.addEventListener(
        "click",
        async () => {

            const text =
                ttsText.value.trim();


            const voice =
                document.getElementById(
                    "voiceSelect"
                ).value;


            if (!text) {

                ttsResult.textContent =
                    "Please enter some text.";

                return;

            }


            generateTTS.disabled =
                true;

            generateTTS.textContent =
                "🦈 Generating...";


            try {

                console.log(
                    "🦈 Sending TTS request..."
                );


                const response =
                    await fetch(
                        `${API_BASE}/api/tts`,
                        {
                            method: "POST",

                            headers: {
                                "Content-Type":
                                    "application/json"
                            },

                            body: JSON.stringify({
                                text,
                                voice
                            })
                        }
                    );


                const data =
                    await response.json();


                if (!response.ok) {

                    throw new Error(
                        data.detail ||
                        "Generation failed."
                    );

                }


                ttsResult.innerHTML = `

                    <p>
                        🦈 Speech generated!
                    </p>

                    <audio
                        controls
                        style="width:100%;"
                        src="${API_BASE}${data.audio_url}"
                    ></audio>

                `;


                await loadActivity();

            }
            catch (error) {

                console.error(
                    "TTS error:",
                    error
                );


                ttsResult.textContent =
                    `❌ ${error.message}`;

            }
            finally {

                generateTTS.disabled =
                    false;

                generateTTS.textContent =
                    "🦈 Generate Speech";

            }

        }
    );

}


// ============================================================
// 🆔 CREATOR ID
// ============================================================

const createCreatorId =
    document.getElementById(
        "createCreatorId"
    );


async function loadCreator() {

    const creatorCreate =
        document.getElementById(
            "creatorCreate"
        );

    const creatorInfo =
        document.getElementById(
            "creatorInfo"
        );

    const creatorId =
        document.getElementById(
            "creatorId"
        );

    const status =
        document.getElementById(
            "creatorVerificationStatus"
        );

    const createdAt =
        document.getElementById(
            "creatorCreatedAt"
        );

    const myVoicesCard =
        document.getElementById(
            "myVoicesCard"
        );


    try {

        const response =
            await fetch(
                `${API_BASE}/api/creator`
            );


        const data =
            await response.json();


        if (!response.ok) {

            throw new Error(
                data.detail ||
                "Could not load Creator ID."
            );

        }


        if (!data.has_creator_id) {

            creatorCreate.style.display =
                "block";

            creatorInfo.style.display =
                "none";

            myVoicesCard.style.display =
                "none";

            return;

        }


        // Creator exists

        creatorCreate.style.display =
            "none";

        creatorInfo.style.display =
            "block";

        myVoicesCard.style.display =
            "block";


        creatorId.textContent =
            data.creator.creator_id;


        if (data.creator.verified) {

            status.textContent =
                "🟢 Verified";

        }
        else {

            status.textContent =
                "🟡 Not Verified";

        }


        createdAt.textContent =
            `Created: ${data.creator.created_at}`;


    }
    catch (error) {

        console.error(
            "Creator load error:",
            error
        );

        const result =
            document.getElementById(
                "creatorResult"
            );

        result.textContent =
            `❌ ${error.message}`;

    }

}


// ============================================================
// CREATE CREATOR ID
// ============================================================

if (createCreatorId) {

    createCreatorId.addEventListener(
        "click",
        async () => {

            const result =
                document.getElementById(
                    "creatorResult"
                );


            createCreatorId.disabled =
                true;

            createCreatorId.textContent =
                "🦈 Creating...";


            try {

                const response =
                    await fetch(
                        `${API_BASE}/api/creator`,
                        {
                            method: "POST"
                        }
                    );


                const data =
                    await response.json();


                if (!response.ok) {

                    throw new Error(
                        data.detail ||
                        "Could not create Creator ID."
                    );

                }


                result.textContent =
                    data.message ||
                    "Creator ID created!";


                await loadCreator();

                await loadActivity();

            }
            catch (error) {

                console.error(
                    "Creator ID error:",
                    error
                );


                result.textContent =
                    `❌ ${error.message}`;

            }
            finally {

                createCreatorId.disabled =
                    false;

                createCreatorId.textContent =
                    "🆔 Create Creator ID";

            }

        }
    );

}


// ============================================================
// VERIFY VOICE
// ============================================================

const verifyVoiceButton =
    document.getElementById(
        "verifyVoiceButton"
    );


if (verifyVoiceButton) {

    verifyVoiceButton.addEventListener(
        "click",
        () => {

            const result =
                document.getElementById(
                    "creatorResult"
                );


            result.textContent =
                "🛡️ Voice verification will be added next.";

        }
    );

}


// ============================================================
// CREATE VOICE
// ============================================================

const createVoiceButton =
    document.getElementById(
        "createVoiceButton"
    );


if (createVoiceButton) {

    createVoiceButton.addEventListener(
        "click",
        () => {

            const result =
                document.getElementById(
                    "creatorResult"
                );


            result.textContent =
                "🎙️ Voice creation will unlock after verification.";

        }
    );

}


// ============================================================
// HTML SAFETY
// ============================================================

function escapeHTML(value) {

    const div =
        document.createElement(
            "div"
        );


    div.textContent =
        value ?? "";


    return div.innerHTML;

}


// ============================================================
// INITIAL LOAD
// ============================================================

loadActivity();